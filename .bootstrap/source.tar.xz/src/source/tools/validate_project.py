#!/usr/bin/env python3
from pathlib import Path
import json
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res"
CONTENT = ROOT / "app/src/main/assets/content"

# XML syntax / duplicate string names.
xml_files = sorted(RES.rglob("*.xml"))
for file in xml_files:
    ET.parse(file)
for rel in ["values/strings.xml", "values-ar/strings.xml", "values-ckb/strings.xml"]:
    names = [n.attrib["name"] for n in ET.parse(RES / rel).getroot().findall("string")]
    assert len(names) == len(set(names)), f"duplicate string key in {rel}"
base_names = {n.attrib["name"] for n in ET.parse(RES / "values/strings.xml").getroot().findall("string")}
for rel in ["values-ar/strings.xml", "values-ckb/strings.xml"]:
    names = {n.attrib["name"] for n in ET.parse(RES / rel).getroot().findall("string")}
    assert names == base_names, f"resource key mismatch: {rel}"

# Quran structural integrity.
def load(name):
    return json.loads((CONTENT / name).read_text(encoding="utf-8"))

ar, en, surahs = load("quran_ar_uthmani.json"), load("quran_en_translation.json"), load("surahs.json")
assert len(ar) == len(en) == 6236
assert len(surahs) == 114
assert sum(s["ayah_count"] for s in surahs) == 6236
assert [v["id"] for v in ar] == list(range(1, 6237))
assert [(v["id"], v["surah"], v["ayah"]) for v in ar] == [(v["id"], v["surah"], v["ayah"]) for v in en]
for name, expected, key in [("quran_page_ranges.json", 604, "page"), ("quran_juz_ranges.json", 30, "juz")]:
    ranges = load(name)
    assert len(ranges) == expected
    cursor = 1
    for i, r in enumerate(ranges, 1):
        assert r[key] == i
        assert r["first_global_ayah"] == cursor
        assert r["last_global_ayah"] >= cursor
        cursor = r["last_global_ayah"] + 1
    assert cursor == 6237

# Kotlin delimiter sanity (comments and common string literals removed).
def cleaned(s: str) -> str:
    s = re.sub(r"//.*", "", s)
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
    s = re.sub(r"'(?:\\.|[^'\\])*'", "''", s)
    return s
for file in sorted((ROOT / "app/src/main/java").rglob("*.kt")):
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for ch in cleaned(file.read_text(encoding="utf-8")):
        if ch in "([{": stack.append(ch)
        elif ch in ")]}":
            assert stack and stack[-1] == pairs[ch], f"delimiter mismatch in {file}"
            stack.pop()
    assert not stack, f"unclosed delimiter in {file}: {stack}"

print(f"Project validation passed: {len(xml_files)} XML resources, {len(base_names)} synchronized UI strings, 6236 aligned ayahs, 604 pages, 30 juz, Kotlin delimiter sanity OK.")
